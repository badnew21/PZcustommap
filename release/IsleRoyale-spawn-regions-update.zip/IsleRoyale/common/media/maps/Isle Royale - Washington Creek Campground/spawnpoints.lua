function SpawnPoints()
  return {
    unemployed = {
      { posX = 35238, posY = 3588, posZ = 0 },
      { posX = 35230, posY = 3586, posZ = 0 },
      { posX = 35244, posY = 3589, posZ = 0 }
    }
  }
end
