function SpawnPoints()
  return {
    unemployed = {
      { posX = 50056, posY = 5689, posZ = 0 },
      { posX = 50050, posY = 5691, posZ = 0 },
      { posX = 50062, posY = 5687, posZ = 0 }
    }
  }
end
