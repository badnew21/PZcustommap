function SpawnPoints()
  return {
    unemployed = {
      { posX = 29575, posY = 8994, posZ = 0 },
      { posX = 29574, posY = 8988, posZ = 0 },
      { posX = 29576, posY = 9000, posZ = 0 }
    }
  }
end
