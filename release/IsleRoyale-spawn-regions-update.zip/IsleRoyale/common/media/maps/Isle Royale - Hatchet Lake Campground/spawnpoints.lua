function SpawnPoints()
  return {
    unemployed = {
      { posX = 60723, posY = 5584, posZ = 0 },
      { posX = 60726, posY = 5578, posZ = 0 },
      { posX = 60719, posY = 5589, posZ = 0 }
    }
  }
end
