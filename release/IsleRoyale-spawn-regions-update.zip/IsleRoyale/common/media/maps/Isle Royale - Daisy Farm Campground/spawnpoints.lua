function SpawnPoints()
  return {
    unemployed = {
      { posX = 81106, posY = 8685, posZ = 0 },
      { posX = 81082, posY = 8690, posZ = 0 },
      { posX = 81112, posY = 8687, posZ = 0 }
    }
  }
end
