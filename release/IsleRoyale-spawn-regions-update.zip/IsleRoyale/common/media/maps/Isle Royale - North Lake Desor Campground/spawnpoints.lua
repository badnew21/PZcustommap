function SpawnPoints()
  return {
    unemployed = {
      { posX = 49300, posY = 3788, posZ = 0 },
      { posX = 49299, posY = 3782, posZ = 0 },
      { posX = 49298, posY = 3776, posZ = 0 }
    }
  }
end
