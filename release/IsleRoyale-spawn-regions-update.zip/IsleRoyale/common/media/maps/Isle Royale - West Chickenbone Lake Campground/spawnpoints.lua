function SpawnPoints()
  return {
    unemployed = {
      { posX = 71208, posY = 6407, posZ = 0 },
      { posX = 71209, posY = 6401, posZ = 0 },
      { posX = 71207, posY = 6413, posZ = 0 }
    }
  }
end
