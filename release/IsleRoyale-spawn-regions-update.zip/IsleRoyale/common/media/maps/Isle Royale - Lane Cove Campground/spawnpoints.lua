function SpawnPoints()
  return {
    unemployed = {
      { posX = 86613, posY = 5168, posZ = 0 },
      { posX = 86613, posY = 5174, posZ = 0 },
      { posX = 86612, posY = 5180, posZ = 0 }
    }
  }
end
