function SpawnPoints()
  return {
    unemployed = {
      { posX = 76243, posY = 9533, posZ = 0 },
      { posX = 76249, posY = 9533, posZ = 0 },
      { posX = 76237, posY = 9533, posZ = 0 }
    }
  }
end
