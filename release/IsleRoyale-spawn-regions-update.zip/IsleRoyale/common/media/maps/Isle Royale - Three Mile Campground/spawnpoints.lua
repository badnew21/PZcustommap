function SpawnPoints()
  return {
    unemployed = {
      { posX = 87106, posY = 8206, posZ = 0 },
      { posX = 87112, posY = 8204, posZ = 0 },
      { posX = 87100, posY = 8209, posZ = 0 }
    }
  }
end
