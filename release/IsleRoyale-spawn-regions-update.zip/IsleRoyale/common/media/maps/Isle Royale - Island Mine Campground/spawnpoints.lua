function SpawnPoints()
  return {
    unemployed = {
      { posX = 43406, posY = 6799, posZ = 0 },
      { posX = 43406, posY = 6793, posZ = 0 },
      { posX = 43407, posY = 6805, posZ = 0 }
    }
  }
end
