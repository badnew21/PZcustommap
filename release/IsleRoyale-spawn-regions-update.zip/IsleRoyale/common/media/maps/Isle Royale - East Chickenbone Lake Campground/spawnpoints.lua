function SpawnPoints()
  return {
    unemployed = {
      { posX = 73661, posY = 6508, posZ = 0 },
      { posX = 73655, posY = 6506, posZ = 0 },
      { posX = 73667, posY = 6510, posZ = 0 }
    }
  }
end
