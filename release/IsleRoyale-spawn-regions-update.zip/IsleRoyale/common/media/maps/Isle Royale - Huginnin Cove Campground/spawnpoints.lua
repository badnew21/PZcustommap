function SpawnPoints()
  return {
    unemployed = {
      { posX = 35022, posY = 1074, posZ = 0 },
      { posX = 35018, posY = 1069, posZ = 0 },
      { posX = 35027, posY = 1078, posZ = 0 }
    }
  }
end
