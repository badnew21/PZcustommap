function SpawnPoints()
  return {
    unemployed = {
      { posX = 55829, posY = 2709, posZ = 0 },
      { posX = 55823, posY = 2709, posZ = 0 },
      { posX = 55835, posY = 2710, posZ = 0 }
    }
  }
end
