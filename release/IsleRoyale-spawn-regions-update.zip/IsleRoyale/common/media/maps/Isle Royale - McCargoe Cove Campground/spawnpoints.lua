function SpawnPoints()
  return {
    unemployed = {
      { posX = 73627, posY = 4723, posZ = 0 },
      { posX = 73633, posY = 4719, posZ = 0 },
      { posX = 73623, posY = 4728, posZ = 0 }
    }
  }
end
