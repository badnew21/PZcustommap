function SpawnPoints()
  return {
    unemployed = {
      { posX = 72876, posY = 9081, posZ = 0 },
      { posX = 72887, posY = 9083, posZ = 0 },
      { posX = 72870, posY = 9080, posZ = 0 }
    }
  }
end
