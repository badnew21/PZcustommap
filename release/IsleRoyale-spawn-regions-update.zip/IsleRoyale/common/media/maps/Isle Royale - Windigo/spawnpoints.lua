function SpawnPoints()
  return {
    unemployed = {
      { posX = 34937, posY = 4081, posZ = 0 },
      { posX = 35403, posY = 3907, posZ = 0 },
      { posX = 34853, posY = 4220, posZ = 0 },
      { posX = 34803, posY = 4005, posZ = 0 },
      { posX = 34936, posY = 3934, posZ = 0 },
      { posX = 35327, posY = 3961, posZ = 0 }
    }
  }
end
