function SpawnPoints()
  return {
    unemployed = {
      { posX = 64362, posY = 3856, posZ = 0 },
      { posX = 64369, posY = 3855, posZ = 0 },
      { posX = 64376, posY = 3854, posZ = 0 }
    }
  }
end
