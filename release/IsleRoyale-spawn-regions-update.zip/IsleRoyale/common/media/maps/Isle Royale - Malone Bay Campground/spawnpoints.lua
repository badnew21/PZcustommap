function SpawnPoints()
  return {
    unemployed = {
      { posX = 61495, posY = 10723, posZ = 0 },
      { posX = 61501, posY = 10722, posZ = 0 },
      { posX = 61496, posY = 10729, posZ = 0 }
    }
  }
end
