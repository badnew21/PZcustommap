function SpawnPoints()
  return {
    unemployed = {
      { posX = 73992, posY = 12565, posZ = 0 },
      { posX = 73986, posY = 12565, posZ = 0 },
      { posX = 73980, posY = 12565, posZ = 0 }
    }
  }
end
