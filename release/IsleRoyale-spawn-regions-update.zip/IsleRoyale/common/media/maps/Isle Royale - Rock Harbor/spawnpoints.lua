function SpawnPoints()
  return {
    unemployed = {
      { posX = 91338, posY = 7874, posZ = 0 },
      { posX = 91068, posY = 7728, posZ = 0 },
      { posX = 91414, posY = 7665, posZ = 0 },
      { posX = 91535, posY = 7847, posZ = 0 },
      { posX = 91194, posY = 7997, posZ = 0 },
      { posX = 91226, posY = 7678, posZ = 0 }
    }
  }
end
