function SpawnPoints()
  return {
    unemployed = {
      { posX = 90876, posY = 7713, posZ = 0 },
      { posX = 90882, posY = 7716, posZ = 0 },
      { posX = 90871, posY = 7709, posZ = 0 }
    }
  }
end
