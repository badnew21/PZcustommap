-- Copy this into Zomboid/Server/ and rename the file to
-- <your server name>_spawnregions.lua - the name has to match
-- the server, not the map.
function SpawnRegions()
    return {
        { name = "Isle Royale", file = "media/maps/Isle Royale/spawnpoints.lua" },
        { name = "Isle Royale - Rock Harbor", file = "media/maps/Isle Royale - Rock Harbor/spawnpoints.lua" },
        { name = "Isle Royale - Windigo", file = "media/maps/Isle Royale - Windigo/spawnpoints.lua" },
        { name = "Isle Royale - Chippewa Harbor Campground", file = "media/maps/Isle Royale - Chippewa Harbor Campground/spawnpoints.lua" },
        { name = "Isle Royale - Daisy Farm Campground", file = "media/maps/Isle Royale - Daisy Farm Campground/spawnpoints.lua" },
        { name = "Isle Royale - East Chickenbone Lake Campground", file = "media/maps/Isle Royale - East Chickenbone Lake Campground/spawnpoints.lua" },
        { name = "Isle Royale - Feldtmann Lake Campground", file = "media/maps/Isle Royale - Feldtmann Lake Campground/spawnpoints.lua" },
        { name = "Isle Royale - Hatchet Lake Campground", file = "media/maps/Isle Royale - Hatchet Lake Campground/spawnpoints.lua" },
        { name = "Isle Royale - Huginnin Cove Campground", file = "media/maps/Isle Royale - Huginnin Cove Campground/spawnpoints.lua" },
        { name = "Isle Royale - Island Mine Campground", file = "media/maps/Isle Royale - Island Mine Campground/spawnpoints.lua" },
        { name = "Isle Royale - Lake Richie Campground", file = "media/maps/Isle Royale - Lake Richie Campground/spawnpoints.lua" },
        { name = "Isle Royale - Lane Cove Campground", file = "media/maps/Isle Royale - Lane Cove Campground/spawnpoints.lua" },
        { name = "Isle Royale - Little Todd Campground", file = "media/maps/Isle Royale - Little Todd Campground/spawnpoints.lua" },
        { name = "Isle Royale - Malone Bay Campground", file = "media/maps/Isle Royale - Malone Bay Campground/spawnpoints.lua" },
        { name = "Isle Royale - McCargoe Cove Campground", file = "media/maps/Isle Royale - McCargoe Cove Campground/spawnpoints.lua" },
        { name = "Isle Royale - Moskey Basin Campground", file = "media/maps/Isle Royale - Moskey Basin Campground/spawnpoints.lua" },
        { name = "Isle Royale - North Lake Desor Campground", file = "media/maps/Isle Royale - North Lake Desor Campground/spawnpoints.lua" },
        { name = "Isle Royale - Rock Harbor Campground", file = "media/maps/Isle Royale - Rock Harbor Campground/spawnpoints.lua" },
        { name = "Isle Royale - South Lake Desor Campground", file = "media/maps/Isle Royale - South Lake Desor Campground/spawnpoints.lua" },
        { name = "Isle Royale - Three Mile Campground", file = "media/maps/Isle Royale - Three Mile Campground/spawnpoints.lua" },
        { name = "Isle Royale - Todd Harbor Campground", file = "media/maps/Isle Royale - Todd Harbor Campground/spawnpoints.lua" },
        { name = "Isle Royale - Washington Creek Campground", file = "media/maps/Isle Royale - Washington Creek Campground/spawnpoints.lua" },
        { name = "Isle Royale - West Chickenbone Lake Campground", file = "media/maps/Isle Royale - West Chickenbone Lake Campground/spawnpoints.lua" },
    }
end
